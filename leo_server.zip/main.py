from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
import httpx
import json
from datetime import datetime

app = FastAPI()

SUPABASE_URL = "https://bmzodeazgmbwpgqkooyz.supabase.co"
SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImJtem9kZWF6Z21id3BncWtvb3l6Iiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc3NjI4MjAxMCwiZXhwIjoyMDkxODU4MDEwfQ.VoMkeWhDvZh9sdgJmHflrLpgOFWHzSJQ_Ws38egTKgs"
ANTHROPIC_KEY = "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"

SYSTEM_PROMPT = """Sos Leo, el asistente virtual de Ecovita, empresa argentina que fabrica productos de limpieza y cuidado del hogar.

PERSONALIDAD: amigable, directo, con onda. Hablás en español rioplatense. Mensajes cortos de 2-3 líneas máximo. Sin bullets ni listas.

CATÁLOGO ECOVITA 2026:

JABONES LÍQUIDOS PARA ROPA:
- Evolution: doypack 800ml y 3L, botella 800ml y 3L. Fórmula equilibrada para el día a día. Versión baja espuma para lavarropas automático.
- Intense: doypack 800ml y 3L. Más fragancia por más tiempo.
- Clásico Bebé: doypack 3L. Cuida ropa de bebé, libre de colorantes y enzimas.
- Para Diluir: botella 500ml concentrado, rinde 3 litros.
- Sport: doypack 800ml. Cuida prendas deportivas, rinde 8 lavados.
- De Origen Vegetal: doypack 800ml.
- Bebé: doypack 800ml. Fórmula hipoalergénica.

SUAVIZANTES:
- Flores Silvestres: doypack 900ml. Suavidad y fragancia duradera.
- Épico: doypack 900ml. Inspirado en fragancias finas, con óleo de argán.
- Único: doypack 900ml. Inspirado en fragancias finas, con óleo de argán.
- Bouquet: doypack 900ml.
- Lirios y Ylang Ylang: doypack 900ml y 3L.
- Orquídeas y Flores de Muguet: doypack 900ml.
- Suavizante Concentrado Épico y Único: botella 500ml, rinde 22 lavados.
- Apresto Lirios: doypack 500ml. Extiende fragancia, facilita el planchado.

SÚPER CONCENTRADOS PARA DILUIR:
- Sachet 27ml rinde 800ml / 150ml rinde 5L: Limpiador de Pisos Lavanda, Coco y Vainilla, Jabón Líquido, Lavavajillas Limón.
- Sobre + Envase: mismas variedades, incluye botella.

LIMPIADORES DE SUPERFICIES:
- Antigrasa: gatillo 500ml y doypack 500ml.
- Vidrios y Multiuso: gatillo 500ml y doypack 500ml.
- Baños: doypack 500ml.
- Madera: doypack 380ml. Sin residuos, limpia y cuida muebles.
- Multisuperficies Cuero y Metal: gatillo 400ml.

LAVAVAJILLAS:
- Detergente Limón: doypack 450ml. Ultra concentrado, elimina la grasa.
- Neutro: botella 500ml. Desengrasa en una pasada.
- Esponja Clásica y con Salvauñas.

REPELENTES:
- Espirales contra mosquitos: 12 unidades.

CONTACTO: ventas@ecovita.com.ar / +54 9 11 2235-7008 / ecovita.com.ar

OBJETIVO: entender qué necesita el usuario y clasificarlo en: A=quiere vender productos Ecovita en su comercio, B=consumidor con consulta sobre productos, C=quiere ser proveedor, D=quiere saber dónde comprar, E=quiere trabajar en Ecovita.

REGLAS:
- Máximo 2 preguntas antes de clasificar.
- Si el primer mensaje ya es claro, clasificá directo.
- Cuando clasificás, avisale que lo conectás con quien corresponde.
- Si preguntan por un producto específico, respondé con info concreta del catálogo.
- Si preguntan qué producto les conviene, hacé una pregunta y recomendá el más adecuado.
- Nunca inventes productos que no están en el catálogo.
- No des precios, derivá a ventas@ecovita.com.ar o +54 9 11 2235-7008.

RESPUESTA: solo texto plano, sin JSON, sin formato especial."""


async def get_historial(contact_id: str) -> list:
    async with httpx.AsyncClient() as client:
        r = await client.get(
            f"{SUPABASE_URL}/rest/v1/conversaciones",
            headers={"apikey": SUPABASE_KEY, "Authorization": f"Bearer {SUPABASE_KEY}"},
            params={"contact_id": f"eq.{contact_id}", "select": "historial"}
        )
        data = r.json()
        if data:
            return data[0]["historial"]
        return []


async def guardar_historial(contact_id: str, historial: list):
    async with httpx.AsyncClient() as client:
        # Verificar si existe
        r = await client.get(
            f"{SUPABASE_URL}/rest/v1/conversaciones",
            headers={"apikey": SUPABASE_KEY, "Authorization": f"Bearer {SUPABASE_KEY}"},
            params={"contact_id": f"eq.{contact_id}", "select": "id"}
        )
        existe = r.json()

        if existe:
            await client.patch(
                f"{SUPABASE_URL}/rest/v1/conversaciones",
                headers={"apikey": SUPABASE_KEY, "Authorization": f"Bearer {SUPABASE_KEY}", "Content-Type": "application/json"},
                params={"contact_id": f"eq.{contact_id}"},
                json={"historial": historial, "actualizado_en": datetime.utcnow().isoformat()}
            )
        else:
            await client.post(
                f"{SUPABASE_URL}/rest/v1/conversaciones",
                headers={"apikey": SUPABASE_KEY, "Authorization": f"Bearer {SUPABASE_KEY}", "Content-Type": "application/json"},
                json={"contact_id": contact_id, "historial": historial, "actualizado_en": datetime.utcnow().isoformat()}
            )


@app.post("/leo")
async def leo(request: Request):
    body = await request.json()
    contact_id = str(body.get("contact_id", ""))
    mensaje = body.get("mensaje", "")

    if not contact_id or not mensaje:
        return JSONResponse({"respuesta": "No pude procesar tu mensaje. Intentá de nuevo."})

    # Obtener historial
    historial = await get_historial(contact_id)

    # Limitar a últimos 10 intercambios
    if len(historial) > 20:
        historial = historial[-20:]

    # Agregar mensaje nuevo
    historial.append({"role": "user", "content": mensaje})

    # Llamar a Claude
    async with httpx.AsyncClient(timeout=30) as client:
        r = await client.post(
            "https://api.anthropic.com/v1/messages",
            headers={
                "x-api-key": ANTHROPIC_KEY,
                "anthropic-version": "2023-06-01",
                "Content-Type": "application/json"
            },
            json={
                "model": "claude-haiku-4-5-20251001",
                "max_tokens": 500,
                "system": SYSTEM_PROMPT,
                "messages": historial
            }
        )
        respuesta = r.json()["content"][0]["text"]

    # Guardar historial actualizado
    historial.append({"role": "assistant", "content": respuesta})
    await guardar_historial(contact_id, historial)

    return JSONResponse({"respuesta": respuesta})


@app.get("/")
async def health():
    return {"status": "Leo activo"}
